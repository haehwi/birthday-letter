# 💌 Birthday Letter Interaktif untuk Pasangan ❤️

Website surat ulang tahun digital yang romantis, manis, dan interaktif yang siap kamu berikan untuk pasanganmu!

---

## ✨ Fitur-Fitur Spesial

1. **Amplop Surat Interaktif (3D Wax Seal)**
   - Tampilan amplop cantik dengan segel lilin merah (*wax seal*).
   - Saat amplop atau segel diklik, segel akan terbuka, amplop membuka perlahan, dan surat cinta muncul dengan efek yang anggun.

2. **Kue Ulang Tahun & Lilin Interaktif**
   - Terdapat kue tart cantik lengkap dengan lilin yang menyala.
   - Pasanganmu bisa membuat harapan (*make a wish*) lalu **mengklik lilin untuk meniupnya**!
   - Efek asap lilin padam, bunyi lonceng ajaib (*sparkle chime*), dan ledakan konfeti akan muncul secara otomatis.

3. **Kertas Surat Romantis & Elegan**
   - Desain kertas surat vintage bertekstur dengan pin dekoratif.
   - Font tulisan tangan estetik (*Caveat* & *Dancing Script*) dengan kata-kata cinta yang menyentuh hati.

4. **Galeri Foto Polaroid Kenangan**
   - Bingkai foto polaroid bergaya miring (*tilted polaroids*) yang estetik dan bisa diisi foto-foto momen kebersamaan kalian.

5. **Musik Instrumen "Best Part" - Daniel Caesar 🎸**
   - Mengalunkan instrumen gitar akustik ikonik dari lagu *Best Part* (Daniel Caesar) dengan progresi akor romantis (Dmaj7 - Am7 - Gmaj7 - Bbmaj7) dan petikan ritmis fingerstyle.
   - **Bekerja 100% Offline**: Melodi gitar disintesis langsung lewat browser tanpa perlu internet.
   - **Bisa Memutar File MP3 Sendiri**: Cukup letakkan file lagumu di folder `music/` dengan nama `music/best-part.mp3`, atau upload langsung lewat tombol **Edit Surat (✏️)**!
   - Tombol kontrol musik 🎵 di pojok kanan atas untuk memutar/menjeda musik kapan saja.

6. **Hujan Konfeti & Hati Melayang**
   - Efek partikel konfeti warna-warni dan hati melayang di latar belakang.

7. **Fitur Edit / Kustomisasi Langsung Tanpa Koding (Tombol ✏️)**
   - Klik tombol **"Edit Surat"** (ikon pensil ✏️ di kanan atas atau tombol di bagian bawah).
   - Kamu bisa:
     - Mengubah nama panggilan pasangan & namamu.
     - Mengganti tanggal.
     - Memilih dari **3 template ucapan cinta** (Romantis Mendalam, Lucu & Ceria, atau Puitis).
     - Mengubah isi tulisan pesan sesuai kata hatimu.
     - Mengunggah foto langsung dari HP / laptopmu untuk polaroid.
   - **Tersimpan Otomatis**: Semua perubahan akan tersimpan di browser sehingga saat halaman dibuka kembali, perubahanmu tetap ada.

---

## 🚀 Cara Membuka Website Ini

1. Buka folder `birthday latter` di komputermu.
2. Klik ganda (**double click**) pada file **`index.html`**.
3. Website akan langsung terbuka di browser (Google Chrome, Microsoft Edge, Firefox, atau Safari) tanpa perlu menginstal aplikasi tambahan apa pun!

---

## 📲 Cara Mengirimkan ke Pasangan

Kamu bisa memberikan website surat ini dengan beberapa cara:

### Cara 1: Kirim Langsung File Folder
- Kompres folder `birthday latter` menjadi file **`.zip`**.
- Kirim via Google Drive, WhatsApp Document, atau Telegram.
- Pasanganmu tinggal mengekstrak dan membuka file `index.html`.

### Cara 2: Online-kan Jadi Link Gratis (Bisa Dibuka di HP Kapan Saja)
Agar pasanganmu bisa membukanya langsung lewat link di HP (seperti https://ultah-sayang.vercel.app):
1. **Netlify Drop** (Sangat mudah, tanpa koding):
   - Kunjungi [app.netlify.com/drop](https://app.netlify.com/drop).
   - Tarik (*drag & drop*) folder `birthday latter` ke halaman tersebut.
   - Dalam 5 detik, kamu akan mendapatkan link website aktif yang bisa langsung kamu kirimkan ke chat WhatsApp pasanganmu!
2. **Vercel / GitHub Pages**:
   - Jika kamu memiliki akun GitHub, upload file ke repository lalu aktifkan GitHub Pages.

---

## 📝 Pilihan Kata-Kata Tambahan (Bisa Disalin ke WhatsApp)

Jika kamu juga ingin mengirim pesan teks singkat di chat WhatsApp tepat jam 00:00:

### Pilihan 1: Romantis & Penuh Harap
> "Selamat ulang tahun untuk orang yang paling berharga dalam hidupku. Terima kasih sudah hadir membawa begitu banyak kehangatan, tawa, dan rasa nyaman yang tak tergantikan. Semoga di usiamu yang baru ini, semesta selalu memelukmu dengan kebaikan, kesehatan, dan kebahagiaan tanpa henti. Aku beruntung memiliki kamu. I love you more than words can say! ❤️🎂"

### Pilihan 2: Manis & Ceria
> "Happy birthday to my favorite human in the world! 🎉 Selamat level up, sayang! Jangan lupa bersyukur, makin glowing, makin dewasa, dan pastinya makin sayang sama aku, hehe. Jangan pernah ragu sama mimpi-mimpimu, karena kamu adalah sosok yang luar biasa hebat. Yuk rayakan hari ini! 🥳✨"

### Pilihan 3: Puitis & Menyentuh
> "Untuk kamu yang selalu menetap di dalam doa-doaku, selamat bertambah usia. Dunia ini luas dan riuh, namun bersamamu aku selalu menemukan rumah untuk pulang. Semoga hatimu selalu dilapangkan, langkahmu diringankan, dan senyum manismu tak pernah padam. Selamat ulang tahun, cintaku. 🌸🕊️"
